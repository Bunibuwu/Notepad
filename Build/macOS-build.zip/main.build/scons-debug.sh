#!/bin/bash
cd "${0%/*}"


"/Library/Frameworks/Python.framework/Versions/3.11/bin/python" "scons-debug.py"
