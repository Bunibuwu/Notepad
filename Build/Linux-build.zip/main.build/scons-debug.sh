#!/bin/bash
cd "${0%/*}"


"/opt/hostedtoolcache/Python/3.11.14/x64/bin/python" "scons-debug.py"
